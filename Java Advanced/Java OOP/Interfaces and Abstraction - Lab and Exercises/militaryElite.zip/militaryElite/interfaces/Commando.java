package militaryElite.interfaces;

import java.util.List;

public interface Commando {

    void addMission(Mission mission);

    List<Mission> getMissions();

}
