package militaryElite.interfaces;

import java.util.List;

public interface Engineer {

    void addRepair(Repair repair);

    List<Repair> getRepairs();

}
