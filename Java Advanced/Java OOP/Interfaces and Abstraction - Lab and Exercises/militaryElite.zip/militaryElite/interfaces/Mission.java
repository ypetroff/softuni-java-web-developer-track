package militaryElite.interfaces;

public interface Mission {

    void completeMission();

    String getCodeName();

    String getState();
}
