import java.util.*;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        Map<String, Team> teams = new HashMap<>();
        String input;

        while (!"END".equals(input = scan.nextLine())) {

            String[] command = input.trim().split(";");
            String name = command[1];

            switch (command[0]) {
                case "Team":
                    try {

                        Team team = new Team(name);
                        teams.putIfAbsent(name, team);

                    } catch (Exception exception) {

                        System.out.println(exception.getMessage());

                    }
                    break;
                case "Add":
                    String playerName = command[2];

                    if(!teams.containsKey(name)) {
                        System.out.printf("Team %s does not exist.%n", name);
                    } else {
                        try {
                            int[] intTokens = Arrays.stream(command).skip(3).mapToInt(Integer::parseInt).toArray();
                            Player player = new Player(playerName, intTokens[0], intTokens[1], intTokens[2], intTokens[3], intTokens[4]);
                            teams.get(name).addPlayer(player);
                        } catch (Exception exception) {
                            System.out.println(exception.getMessage());
                        }
                    }
                    break;
                case "Remove":
                    try {
                        teams.get(name).removePlayer(command[2]);
                    }catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "Rating":
                    if(!teams.containsKey(name)) {
                        System.out.printf("Team %s does not exist.%n", name);
                    } else {
                        System.out.printf("%s - %d", name, Math.round(teams.get(name).getRating()));
                    }
                    break;
            }
        }
    }
}