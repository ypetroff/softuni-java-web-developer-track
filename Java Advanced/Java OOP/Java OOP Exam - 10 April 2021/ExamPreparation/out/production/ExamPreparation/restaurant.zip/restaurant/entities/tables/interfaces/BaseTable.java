package restaurant.entities.tables.interfaces;

import restaurant.entities.drinks.interfaces.Beverages;
import restaurant.entities.healthyFoods.interfaces.HealthyFood;

import java.util.Collection;

public abstract class BaseTable implements Table { //todo implement logic for all methods

    private Collection<HealthyFood> healthyFood; /** may be unmodifiable collection **/
    private Collection<Beverages> beverages;
    private int number;
    private int size;
    private int numberOfPeople;
    private double pricePerPerson;
    private boolean isReservedTable;
    private double allPeople;

    //int number, int size, double pricePerPerson


    public BaseTable(int number, int size, double pricePerPerson) {
        //todo setters for all
    }

    @Override
    public int getTableNumber() {
        return 0;
    }

    @Override
    public int getSize() {
        return 0;
    }

    @Override
    public int numberOfPeople() {
        return 0;
    }

    @Override
    public double pricePerPerson() {
        return 0;
    }

    @Override
    public boolean isReservedTable() {
        return false;
    }

    @Override
    public double allPeople() {
        return 0;
    }

    @Override
    public void reserve(int numberOfPeople) {

    }

    @Override
    public void orderHealthy(HealthyFood food) {

    }

    @Override
    public void orderBeverages(Beverages beverages) {

    }

    @Override
    public double bill() {
        return 0;
    }

    @Override
    public void clear() {

    }

    @Override
    public String tableInformation() {
        return null;
    }
}
