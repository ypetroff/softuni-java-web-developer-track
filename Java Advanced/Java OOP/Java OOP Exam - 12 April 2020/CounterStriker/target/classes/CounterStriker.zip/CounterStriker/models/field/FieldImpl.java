package CounterStriker.models.field;

import CounterStriker.models.guns.Gun;
import CounterStriker.models.players.Player;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public abstract class FieldImpl implements Field {

    @Override
    public String start(Collection<Player> players) {
        List<Player> terrorists = players.stream()
                .filter(p -> p.getClass().getSimpleName().equals("Terrorist"))
                .collect(Collectors.toList());
        List<Player> counterTerrorists = players.stream()
                .filter(p -> !p.getClass().getSimpleName().equals("Terrorist"))
                .collect(Collectors.toList());

        while (AreAlive(terrorists)) {

            shooting(terrorists, counterTerrorists);

            if (!AreAlive(counterTerrorists)) {
                return "Terrorist wins!";
            }

            shooting(counterTerrorists, terrorists);

        }
        return "Counter Terrorist wins!";
    }

    private void shooting(List<Player> attackers, List<Player> defenders) {
        attackers.stream()
                .filter(Player::isAlive)
                .forEach(attacker -> {
                    int fire = attacker.getGun().fire();
                    defenders.stream().filter(Player::isAlive).forEach(defender -> defender.takeDamage(fire));
                });
    }

    private boolean AreAlive(List<Player> players) {
        return players.stream().anyMatch(Player::isAlive);
    }


}
