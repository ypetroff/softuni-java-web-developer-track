package CounterStriker.utils;

public class CheckIntegerValidity {

    public static void isNotNegative(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Bullets cannot be below 0.");
        }
    }

    public static void isNotNegative(int n, String attribute) {
        if (n < 0) {
            throw new IllegalArgumentException(
                    attribute.equals("health")
                            ? "Player health cannot be below 0."
                            : "Player armor cannot be below 0.");
        }
    }
}
