package CounterStriker.utils;

public class CheckStringValidity {

    public static void isValid(String str, String entity) {

        if (str == null || str.trim().isEmpty()) {

            throw new NullPointerException(entity.equals("gun")
                    ? "Gun cannot be null or empty."
                    : "Username cannot be null or empty.");
        }
    }
}
