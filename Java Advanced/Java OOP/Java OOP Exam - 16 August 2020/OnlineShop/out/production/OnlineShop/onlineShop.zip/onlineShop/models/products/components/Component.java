package onlineShop.models.products.components;

import onlineShop.models.Product;

public interface Component extends Product {

    int getGeneration();
}
