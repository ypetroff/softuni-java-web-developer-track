package onlineShop.models.products.peripherals;

import onlineShop.models.Product;

public interface Peripheral extends Product {
    String getConnectionType();
}
