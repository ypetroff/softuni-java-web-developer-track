package fairyShop.models;

public class Happy extends BaseHelper{

    private final static int INITIAL_ENERGY_UNITS = 100;

    public Happy(String name) {
        super(name, INITIAL_ENERGY_UNITS);
    }
}
