package fairyShop.models;

public class InstrumentImpl implements Instrument{

    private int power;

    public InstrumentImpl(int power) {
       //todo setter
    }

    @Override
    public int getPower() {
        return 0;
    }

    @Override
    public void use() {

    }

    @Override
    public boolean isBroken() {
        return false;
    }
}
