package fairyShop.models;

public class Sleepy extends BaseHelper {

    private final static int INITIAL_ENERGY_UNITS = 50;

    public Sleepy(String name) {
        super(name, INITIAL_ENERGY_UNITS);
    }
}
