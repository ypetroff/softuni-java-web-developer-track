package fairyShop.repositories;

import fairyShop.models.Present;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public class PresentRepository implements Repository<Present> {

    Map<String, Present> presents;

    public PresentRepository() {
        presents = new LinkedHashMap<>();
    }

    @Override
    public Collection<Present> getModels() {
        return null;
    }

    @Override
    public void add(Present model) {

    }

    @Override
    public boolean remove(Present model) {
        return false;
    }

    @Override
    public Present findByName(String name) {
        return null;
    }
}
