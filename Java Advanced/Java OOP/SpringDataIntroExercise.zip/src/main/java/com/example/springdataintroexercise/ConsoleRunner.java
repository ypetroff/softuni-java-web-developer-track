package com.example.springdataintroexercise;

import com.example.springdataintroexercise.entities.Author;
import com.example.springdataintroexercise.entities.Book;
import com.example.springdataintroexercise.repositories.AuthorRepository;
import com.example.springdataintroexercise.repositories.BookRepository;
import com.example.springdataintroexercise.services.AuthorService;
import com.example.springdataintroexercise.services.SeedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

@Component
public class ConsoleRunner implements CommandLineRunner {

    private final LocalDate YEAR_1990 = LocalDate.of(1990, 1, 1);
    private final LocalDate YEAR_2000 = LocalDate.of(2000, 12, 31);
    private final String AUTHOR_FIRST_NAME = "George";
    private final String AUTHOR_LAST_NAME = "Powell";

    private final SeedService seedService;
    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;
    private final AuthorService authorService;

    @Autowired
    public ConsoleRunner(
            SeedService seedService,
            BookRepository bookRepository,
            AuthorRepository authorRepository,
            AuthorService authorService) {
        this.seedService = seedService;
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
        this.authorService = authorService;
    }

    @Override
    public void run(String... args) throws Exception {

        this.seedService.seedAll();
        this.booksWithReleaseDateAfter2000();
        this.allAuthorsWithABookBefore1990();
        this.allAuthorsOrderedByTheNumberOfTheirBooks();
        this.allBooksByAnAuthor();
    }

    private void allBooksByAnAuthor() {
      Author author =  this.authorRepository.findByFirstNameAndLastName
                                                    (AUTHOR_FIRST_NAME, AUTHOR_LAST_NAME);

      try {
          author.getBooks().stream()
                  .sorted(Comparator.comparing(Book::getReleaseDate).reversed()
                          .thenComparing(Book::getTitle))
                  .forEach(b -> System.out.printf("%s %s - %s - %s%n",
                          b.getAuthor().getFirstName(),
                          b.getAuthor().getLastName(),
                          b.getReleaseDate(),
                          b.getTitle()));
      } catch (NullPointerException e) {
          e.printStackTrace();
      }

    }

    @Transactional(propagation= Propagation.REQUIRED, readOnly=true, noRollbackFor=Exception.class)
    public void allAuthorsOrderedByTheNumberOfTheirBooks() {

        List<Author> authors = this.authorRepository.findAll();

        authors.stream()
                .sorted((a1, a2) -> a2.getBooks().size() - a1.getBooks().size())
                .forEach(a -> System.out.printf("%s %s %d%n",
                        a.getFirstName(),
                        a.getLastName(),
                        a.getBooks().size()));
    }


    private void allAuthorsWithABookBefore1990() {


        List<Author> authors = this.authorRepository.findDistinctByBooksReleaseDateBefore(YEAR_1990);

        authors.forEach(a -> System.out.printf("%s %s%n", a.getFirstName(), a.getLastName()));
    }

    private void booksWithReleaseDateAfter2000() {



        List<Book> books = this.bookRepository.findAllByReleaseDateAfter(YEAR_2000);

        books.forEach(b -> System.out.println(b.getTitle()));
    }
}
