package com.example.springdataintroexercise.services;

import com.example.springdataintroexercise.entities.Author;

public interface AuthorService {

    Author getRandomAuthor();


}
