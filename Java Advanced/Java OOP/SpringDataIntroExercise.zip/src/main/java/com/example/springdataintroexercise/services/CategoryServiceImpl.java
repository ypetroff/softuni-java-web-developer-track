package com.example.springdataintroexercise.services;

import com.example.springdataintroexercise.entities.Category;
import com.example.springdataintroexercise.repositories.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

@Service
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;

    @Autowired
    public CategoryServiceImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public Set<Category> getRandomCategories() {
        int size = (int) this.categoryRepository.count();

        int categoryCount = getRandomNumber(size);

        Set<Integer> categories = new HashSet<>();

        int index = getRandomNumber(size);
        while (categories.size() < categoryCount) {

            if(this.categoryRepository.findById(index).isPresent()) {
                categories.add(index);
            }

           index =  getRandomNumber(size);
        }

        return new HashSet<>(this.categoryRepository.findAllById(categories));

    }

    private int getRandomNumber(int size) {
        return new Random().nextInt(size) + 1;
    }
}
