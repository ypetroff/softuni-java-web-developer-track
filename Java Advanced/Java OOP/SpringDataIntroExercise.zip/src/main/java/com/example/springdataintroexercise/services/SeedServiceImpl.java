package com.example.springdataintroexercise.services;

import com.example.springdataintroexercise.entities.Author;
import com.example.springdataintroexercise.entities.Book;
import com.example.springdataintroexercise.entities.Category;
import com.example.springdataintroexercise.enums.AgeRestriction;
import com.example.springdataintroexercise.enums.EditionType;
import com.example.springdataintroexercise.repositories.AuthorRepository;
import com.example.springdataintroexercise.repositories.BookRepository;
import com.example.springdataintroexercise.repositories.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class SeedServiceImpl implements SeedService {

    private static final String RESOURCE_PATH = "src\\main\\resources\\files";

    private static final String AUTHOR_FILE_NAME = "\\authors.txt";
    private static final String AUTHOR_PATH = String.format("%s%s",
            RESOURCE_PATH,
            AUTHOR_FILE_NAME);

    private static final String CATEGORIES_FILE_NAME = "\\categories.txt";
    private static final String CATEGORIES_PATH = String.format("%s%s",
            RESOURCE_PATH,
            CATEGORIES_FILE_NAME);

    private static final String BOOKS_FILE_NAME = "\\books.txt";
    private static final String BOOKS_PATH = String.format("%s%s",
            RESOURCE_PATH,
            BOOKS_FILE_NAME);


    @Autowired
    private AuthorRepository authorRepository;
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private BookRepository bookRepository;
    @Autowired
    private AuthorService authorService;
    @Autowired
    private CategoryService categoryService;

    //TODO: Refactor seed methods by adding a common method(path, func, func, repo)


    @Override
    public void seedAuthor() throws IOException {

        Files.readAllLines(Path.of(AUTHOR_PATH).toAbsolutePath())
                .stream()
                .filter(x -> !x.isBlank())
                .map(x -> x.split("\\s+"))
                .map(x -> new Author(x[0], x[1]))
                .forEach(authorRepository::save);

    }

    @Override
    public void seedCategories() throws IOException {

        Files.readAllLines(Path.of(CATEGORIES_PATH).toAbsolutePath())
                .stream()
                .filter(x -> !x.isBlank())
                .map(Category::new)
                .forEach(categoryRepository::save);
    }

    @Override
    public void seedBooks() throws IOException {

        Files.readAllLines(Path.of(BOOKS_PATH).toAbsolutePath())
                .stream()
                .filter(x -> !x.isBlank())
                .map(this::bookObject)
                .forEach(bookRepository::save);
    }

    private Book bookObject(String s) {

        String[] bookParts = s.split("\\s+");

        int editionTypeIndex = Integer.parseInt(bookParts[0]);
        EditionType editType = EditionType.values()[editionTypeIndex];

        LocalDate publicationDate = LocalDate.parse(bookParts[1],
                DateTimeFormatter.ofPattern("d/M/yyyy"));

        int copies = Integer.parseInt(bookParts[2]);

        BigDecimal price = new BigDecimal(bookParts[3]);

        int ageRestrictionIndex = Integer.parseInt(bookParts[4]);

        AgeRestriction ageRestriction = AgeRestriction.values()[ageRestrictionIndex];

        String title = Arrays.stream(bookParts)
                .skip(5)
                .collect(Collectors.joining(" "));

        Author author = authorService.getRandomAuthor();

        Set<Category> categories = categoryService.getRandomCategories();


        return new Book(
                title, String.valueOf(editType), price, copies, publicationDate,
                String.valueOf(ageRestriction), author, categories);
    }
}
