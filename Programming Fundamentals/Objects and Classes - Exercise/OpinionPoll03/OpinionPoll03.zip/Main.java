package OpinionPoll03;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int linesOfPersonalInfo = Integer.parseInt(scanner.nextLine());
        List<Person> people = new ArrayList<>();

        for (int i = 0; i < linesOfPersonalInfo; i++) {
            String[] personalInfo = scanner.nextLine().split(" ");
            String name = personalInfo[0];
            int age = Integer.parseInt(personalInfo[1]);

            Person person = new Person();
            person.setName(name);
            person.setAge(age);
            people.add(person);
        }

        List <Person> result = people.stream()
                .filter(p -> p.getAge() > 30)
                .collect(Collectors.toList());

        Collections.sort(result, new Comparator<Person>() {
            @Override
            public int compare(Person o1, Person o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });

        result.forEach(p -> System.out.println(p.printPeopleOver30()));


    }


}
